$(document).ready(function(){
    $('.sidenav').sidenav({draggable: true}
      );
     
    });
    $(document).ready(function(){
    $('.tap-target').tapTarget();
  });
  $(document).ready(function(){
    $('.parallax').parallax();
  });
  $(document).ready(function(){
    $('.fixed-action-btn').floatingActionButton();
  });
  $(document).ready(function(){
    $('.modal').modal();
  });
  



$('.dropdown-trigger').dropdown({hover:true});



