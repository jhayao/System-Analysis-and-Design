function active_account(account) {
    localStorage.setItem('active', account);
}

function signup() {
    var fname = document.getElementById('first').value;
    
    var email = document.getElementById('email').value;
    var pass = document.getElementById('pass').value;
    var arr = [];
    arr.push(fname);
    
    arr.push(pass);
    for (i = 0; i < localStorage.length; i++) {
        if (localStorage.key(i) == email) {
            alert('Email Already In Used!');
            return;
        }

    }
    localStorage.setItem(email, JSON.stringify(arr));
    clear();
    modal_open();

}

function clear() {
    document.getElementById('first').value = "";
    
    email = document.getElementById('email').value = "";
    document.getElementById('pass').value = "";
}

function modal_open() {
    $('#modal1').modal();
    $('#modal1').modal('open');
}

function modal_open2() {
    $('#modal2').modal();
    $('#modal2').modal('open');
}

function modal_open3() {
    $('#modal3').modal();
    $('#modal3').modal('open');
}

function modal_ok() {
    window.location.href = "login.html";
}

function modal_login() {
    window.location.href = "main.html";
}

function log_in() {
    var email = document.getElementById('email').value;
    var pass = document.getElementById('pass').value;
    var i = 0;
    var password;
    var key;
    if (localStorage.length > 0)
        for (i = 0; i < localStorage.length; i++) {
            if (localStorage.key(i) == email) {
                key = localStorage.key(i);
                password = JSON.parse(localStorage.getItem(key))[1];
                if (password == pass) {
                    modal_open();
                    active_account(email);
                    return;
                } else {
                    modal_open2();
                }
                return;
            } else if (i == localStorage.length - 1) {

                modal_open3();
            }
        }
    else {
        alert('No Account Registered Try Signing Up First');
    }
}


function new_contact() {
    var fname = document.getElementById('first').value;
    var lname = document.getElementById('last').value;
    var phone = document.getElementById('phone').value;
    var email = document.getElementById('email').value;
    var acc = localStorage.getItem('active');
    var arr = [];
    var i = 0;
    var x = 0;
    var num = 0;
    arr.push(acc);
    arr.push(fname);
    arr.push(lname);
    arr.push(phone);
    arr.push(email);
    var empty=true;
    for (i = 0; localStorage.length > i; i++) {
        for (x = 0; localStorage.length > x; x++) {
            if (localStorage.key(i) == "phonebook_" + x) {
                empty=false;
                break;
            }


        }
    }
    var key="";
    if (empty==true)
    {
        key="phonebook_0";
    }
    else
        key = "phonebook_" + (x+1);
    

    localStorage.setItem(key, JSON.stringify(arr));
    show_contacts();
    $('#modal1').modal();
    $('#modal1').modal('close');
    document.getElementById('sub').reset();

}

function show_contacts() {
    var i = 0;
    var x = 0;
    var list = "";
    var fname;
    var lname;
    var phone;
    var email;
    var key = "";
    var counter = 0;
    for (i = 0; localStorage.length > i; i++) {
        for (x = 0; localStorage.length > x; x++) 
        {
            if (localStorage.key(i) == "phonebook_" + x) {
                key = localStorage.key(i);
                if (localStorage.getItem('active') == JSON.parse(localStorage.getItem(key))[0]) {
                    fname = JSON.parse(localStorage.getItem(key))[1];
                    lname = JSON.parse(localStorage.getItem(key))[2];
                    phone = JSON.parse(localStorage.getItem(key))[3];
                    email = JSON.parse(localStorage.getItem(key))[4];
                    counter++;
                    
                    list = list + "<li  class=\"collection-item avatar li\"><img src=\"img/user.png\"  class=\"circle\"><span class=\"title\">" + fname + " " + lname + "</span> <p>" + phone + " </p><p class=\"email_phone"+ counter +" \">  " + email + "  </p> <a id=\""+key+"\" href=\"#\" onclick=\"javascript:modal_delete(this.id);\" class=\"secondary-content\"><i class=\"material-icons \">delete</i></a>   </li>";
                }
            }
        }
    }
    
    document.getElementById('collection').innerHTML = list;
}

function modal_delete(id) {
    $('#delete').modal();
    $('#delete').modal('open');
    active_id(id);
}

function delete_phone() {
    var key = "";
    for (i = 0; localStorage.length > i; i++) {
        for (x = 0; localStorage.length > x; x++) {
            if(localStorage.key(x)==localStorage.getItem('active_id'))
                key=localStorage.key(x);
        }
    }
    alert(key);
    localStorage.removeItem(key);
    show_contacts();
    $('#delete').modal();
    $('#delete').modal('close');
    active_id('none');
}

function active_id(id) {

    localStorage.setItem("active_id",id);

}

function delete_all() {
    var i = 0;
    var x = 0;
    var list = "";
    var fname;
    var lname;
    var phone;
    var email;
    var key = "";
    var counter = 0;
    for (i = 0; localStorage.length > i; i++) {
        for (x = 0; localStorage.length > x; x++) {
            if (localStorage.key(i) == "phonebook_" + x) {
                key = localStorage.key(i);
                if (localStorage.getItem('active') == JSON.parse(localStorage.getItem(key))[0]) {
                    localStorage.removeItem(key);
                }
            }
        }
    }
    show_contacts();
    $('#delete_all').modal();
    $('#delete_all').modal('close');
}