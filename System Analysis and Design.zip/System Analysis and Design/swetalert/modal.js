function success()
				{
					swal({
						title: "Login now?",
						text: "Proceed to login page?",
						icon: "success",
						buttons: true,
						dangerMode: false,
					  })
					  .then((willDelete) => {
						if (willDelete) {
						  window.location.href="index2.html";
						} else {
						  window.location.reload();
						}
					  });
		}

function noaccount()
{
	swal ( "Oops" ,  "Account Not Found!" ,  "error" )
}

function wrongpass()
{

	swal ( "Oops" ,  "Wrong Password" ,  "warning" )
}
function wrongemail()
{
	swal ( "Oops" ,  "Username not Registered" ,  "warning" )
}
function already()
{
	swal ( "Oops" ,  "Username already in used" ,  "warning" )
}
function successlogin()
{
	swal({  title: "Success...",
	text: "You have successfully login..",
	icon: "/System Analysis and Design/swetalert/log.png",
}).then(function()
{

	window.location.href='main.html';
});

}